define( function ( require ) {

	"use strict";

	return {
		app_slug : 'homedigital',
		wp_ws_url : 'http://homedigitalmkt.com/wp-appkit-api/homedigital',
		wp_url : 'http://homedigitalmkt.com',
		theme : 'q-android',
		version : '0.1',
		app_type : 'phonegap-build',
		app_title : 'Home',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '.C@y>*Ez]<]a~CG{Fk]1MxTO_S~!|+73RnB)=h2ss^:{@92mf<%+Jp6(HFK[nzVI',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
